package com.freefire.enhancer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class FloatingButtonService extends Service {
    private static final String TAG = "FloatingButtonService";
    private static final int NOTIFICATION_ID = 1001;
    
    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;
    private PreferenceManager preferenceManager;
    private Handler handler = new Handler(Looper.getMainLooper());
    
    // This is used to track if the service is running
    public static boolean isRunning = false;
    
    // Track if a glow wall action is currently in progress
    private boolean isActionInProgress = false;
    
    // Track touch positions
    private int initialX;
    private int initialY;
    private float initialTouchX;
    private float initialTouchY;
    private boolean isMoving = false;
    
    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        preferenceManager = new PreferenceManager(this);
        createNotificationChannel();
        initializeFloatingButton();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, createNotification());
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
        isRunning = false;
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "enhancer_service_channel",
                    getString(R.string.channel_name),
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription(getString(R.string.channel_description));
            
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    
    private Notification createNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, "enhancer_service_channel")
                .setContentTitle(getString(R.string.floating_service_notification_title))
                .setContentText(getString(R.string.floating_service_notification_text))
                .setSmallIcon(R.drawable.app_icon)
                .setContentIntent(pendingIntent)
                .build();
    }
    
    private void initializeFloatingButton() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        Point size = new Point();
        windowManager.getDefaultDisplay().getSize(size);
        
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_button, null);
        
        // Get saved position or use default
        initialX = preferenceManager.getButtonX();
        initialY = preferenceManager.getButtonY();
        
        int layoutFlag;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
        }
        
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                layoutFlag,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        
        // Apply preferences for button size and transparency
        float scale = (preferenceManager.getButtonSize() / 100f) + 0.5f;
        floatingView.setScaleX(scale);
        floatingView.setScaleY(scale);
        floatingView.setAlpha(preferenceManager.getButtonTransparency() / 100f);
        
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = initialX;
        params.y = initialY;
        
        ImageButton floatingButton = floatingView.findViewById(R.id.floatingButton);
        
        // Add the view to window manager
        windowManager.addView(floatingView, params);
        
        // Set touch listener
        floatingView.setOnTouchListener((view, motionEvent) -> {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    initialX = params.x;
                    initialY = params.y;
                    initialTouchX = motionEvent.getRawX();
                    initialTouchY = motionEvent.getRawY();
                    isMoving = false;
                    return true;
                
                case MotionEvent.ACTION_MOVE:
                    // Only consider it a move if it moves more than a small threshold
                    if (Math.abs(initialTouchX - motionEvent.getRawX()) > 10 ||
                            Math.abs(initialTouchY - motionEvent.getRawY()) > 10) {
                        isMoving = true;
                        params.x = initialX + (int) (motionEvent.getRawX() - initialTouchX);
                        params.y = initialY + (int) (motionEvent.getRawY() - initialTouchY);
                        windowManager.updateViewLayout(floatingView, params);
                    }
                    return true;
                
                case MotionEvent.ACTION_UP:
                    // Save position
                    preferenceManager.setButtonX(params.x);
                    preferenceManager.setButtonY(params.y);
                    
                    // If not moving, it's a click
                    if (!isMoving) {
                        performSitUpGlowWallAction();
                    }
                    return true;
            }
            return false;
        });
    }
    
    private void performSitUpGlowWallAction() {
        if (isActionInProgress) {
            return;
        }
        
        isActionInProgress = true;
        
        // Show visual feedback
        floatingView.animate().alpha(1.0f).setDuration(100).withEndAction(() -> {
            floatingView.animate().alpha(preferenceManager.getButtonTransparency() / 100f).setDuration(300);
        });
        
        // Delay the action according to preferences (default 500ms = 0.5 seconds)
        int delay = preferenceManager.getActivationDelay();
        handler.postDelayed(this::executeSitUpGlowWallAction, delay);
    }
    
    private void executeSitUpGlowWallAction() {
        // Execute the actual action: simulate touch events for sit-up glow wall

        // The code below would need to be adjusted based on the exact locations
        // where touches need to be simulated for the sit-up glow wall action
        // in Free Fire. This is a mock implementation that logs the action and
        // shows a toast.
        
        Log.d(TAG, "Executing sit-up glow wall action");
        Toast.makeText(this, "Sit-up Glow Wall Activated!", Toast.LENGTH_SHORT).show();
        
        // IMPORTANT: In a real implementation, this is where you would use the
        // Android Accessibility Service or Instrumentation to perform the
        // sit-up glow wall action. However, this would require
        // special permissions and considerations.
        
        handler.postDelayed(() -> isActionInProgress = false, 1000);
    }
} 