package com.freefire.enhancer;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int OVERLAY_PERMISSION_REQ_CODE = 1234;
    
    private SeekBar transparencySeekBar, sizeSeekBar, delaySeekBar;
    private Switch autoStartSwitch;
    private Button startServiceButton, stopServiceButton;
    private PreferenceManager preferenceManager;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        preferenceManager = new PreferenceManager(this);
        
        // Initialize UI components
        transparencySeekBar = findViewById(R.id.transparencySeekBar);
        sizeSeekBar = findViewById(R.id.sizeSeekBar);
        delaySeekBar = findViewById(R.id.delaySeekBar);
        autoStartSwitch = findViewById(R.id.autoStartSwitch);
        startServiceButton = findViewById(R.id.startServiceButton);
        stopServiceButton = findViewById(R.id.stopServiceButton);
        
        // Set initial values from preferences
        transparencySeekBar.setProgress(preferenceManager.getButtonTransparency());
        sizeSeekBar.setProgress(preferenceManager.getButtonSize());
        delaySeekBar.setProgress(preferenceManager.getActivationDelay());
        autoStartSwitch.setChecked(preferenceManager.getAutoStart());
        
        // Setup listeners
        transparencySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                preferenceManager.setButtonTransparency(progress);
                if (isServiceRunning()) {
                    restartService();
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        sizeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                preferenceManager.setButtonSize(progress);
                if (isServiceRunning()) {
                    restartService();
                }
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        delaySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                preferenceManager.setActivationDelay(progress);
            }
            
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        
        autoStartSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            preferenceManager.setAutoStart(isChecked);
        });
        
        startServiceButton.setOnClickListener(v -> {
            if (checkOverlayPermission()) {
                startFloatingButtonService();
            }
        });
        
        stopServiceButton.setOnClickListener(v -> {
            stopFloatingButtonService();
        });
    }
    
    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, 
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQ_CODE);
            Toast.makeText(this, "Please grant overlay permission", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_PERMISSION_REQ_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startFloatingButtonService();
            } else {
                Toast.makeText(this, "Overlay permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    private void startFloatingButtonService() {
        Intent intent = new Intent(this, FloatingButtonService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        Toast.makeText(this, "Floating button service started", Toast.LENGTH_SHORT).show();
    }
    
    private void stopFloatingButtonService() {
        Intent intent = new Intent(this, FloatingButtonService.class);
        stopService(intent);
        Toast.makeText(this, "Floating button service stopped", Toast.LENGTH_SHORT).show();
    }
    
    private boolean isServiceRunning() {
        // A simple check - will be enhanced in a real app
        // This is just for demonstration
        return FloatingButtonService.isRunning;
    }
    
    private void restartService() {
        stopFloatingButtonService();
        startFloatingButtonService();
    }
} 