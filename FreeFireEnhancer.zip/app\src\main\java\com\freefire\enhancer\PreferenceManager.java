package com.freefire.enhancer;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceManager {
    private static final String PREF_NAME = "FreeFireEnhancerPrefs";
    private static final String KEY_BUTTON_TRANSPARENCY = "button_transparency";
    private static final String KEY_BUTTON_SIZE = "button_size";
    private static final String KEY_ACTIVATION_DELAY = "activation_delay";
    private static final String KEY_AUTO_START = "auto_start";
    private static final String KEY_BUTTON_X = "button_x";
    private static final String KEY_BUTTON_Y = "button_y";
    
    private SharedPreferences prefs;
    
    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }
    
    public int getButtonTransparency() {
        return prefs.getInt(KEY_BUTTON_TRANSPARENCY, 50);
    }
    
    public void setButtonTransparency(int value) {
        prefs.edit().putInt(KEY_BUTTON_TRANSPARENCY, value).apply();
    }
    
    public int getButtonSize() {
        return prefs.getInt(KEY_BUTTON_SIZE, 50);
    }
    
    public void setButtonSize(int value) {
        prefs.edit().putInt(KEY_BUTTON_SIZE, value).apply();
    }
    
    public int getActivationDelay() {
        return prefs.getInt(KEY_ACTIVATION_DELAY, 500);
    }
    
    public void setActivationDelay(int value) {
        prefs.edit().putInt(KEY_ACTIVATION_DELAY, value).apply();
    }
    
    public boolean getAutoStart() {
        return prefs.getBoolean(KEY_AUTO_START, false);
    }
    
    public void setAutoStart(boolean value) {
        prefs.edit().putBoolean(KEY_AUTO_START, value).apply();
    }
    
    public int getButtonX() {
        return prefs.getInt(KEY_BUTTON_X, 100);
    }
    
    public void setButtonX(int value) {
        prefs.edit().putInt(KEY_BUTTON_X, value).apply();
    }
    
    public int getButtonY() {
        return prefs.getInt(KEY_BUTTON_Y, 100);
    }
    
    public void setButtonY(int value) {
        prefs.edit().putInt(KEY_BUTTON_Y, value).apply();
    }
} 