# Free Fire Enhancer

A customizable floating button app that helps Free Fire players quickly activate the sit-up glow wall feature.

## Features

- Floating button that can be placed anywhere on screen
- Automatically activates sit-up glow wall with a 0.5-second delay (customizable)
- Adjustable button size and transparency
- Option to auto-start on device boot
- Movable button - simply drag to reposition
- Minimal performance impact

## How to Use

1. Install the app
2. Grant overlay permission when prompted
3. Customize button appearance and behavior in the app
4. Click "Start Floating Button"
5. The floating button will appear on screen
6. Tap the button during gameplay to activate the sit-up glow wall
7. Drag the button to reposition if needed

## Build Instructions

This project uses the standard Android Gradle build system:

```
./gradlew assembleRelease
```

For CI/CD, this project is configured to work with Codemagic.io.

## Privacy and Security

This app only requires the minimal permissions needed to function:
- SYSTEM_ALERT_WINDOW: Needed for the floating button
- FOREGROUND_SERVICE: Needed to keep the service running
- RECEIVE_BOOT_COMPLETED: Optional, only used if auto-start is enabled

The app does not collect any personal data, analytics, or telemetry.

## Disclaimer

This app is provided as-is, without any warranty. Users should ensure they understand and comply with the Terms of Service of Free Fire. The developers are not responsible for any account bans or other issues that may arise from using this app. 